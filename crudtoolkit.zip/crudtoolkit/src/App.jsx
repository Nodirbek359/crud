import React, { useEffect } from 'react';
import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPosts, addPost, updatePost, deletePost } from './features/posts/postsSlice';

function App() {
  const dispatch = useDispatch();
  const posts = useSelector((state) => state.posts.data);
  const status = useSelector((state) => state.posts.status);
  const error = useSelector((state) => state.posts.error);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchPosts());
    }
  }, [status, dispatch]);

  const handleAddPost = () => {
    dispatch(addPost({ id: Date.now(), title: 'New Post', body: 'Lorem ipsum' }));
  };

  const handleUpdatePost = (id, title, body) => {
    dispatch(updatePost({ id, title, body }));
  };

  const handleDeletePost = (id) => {
    dispatch(deletePost(id));
  };

  if (status === 'loading') {
    return <div>Loading...</div>;
  }

  if (status === 'failed') {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="App">
      <h1>CRUD,  Redux Toolkit</h1>
      <button className='btn' onClick={handleAddPost}>Add Post</button>
      <ol>
        {posts.map((post) => (
          <li key={post.id}>
            <input
              className='oft'
              type="text"
              value={post.title}
              onChange={(e) => handleUpdatePost(post.id, e.target.value, post.body)}
            />
            <button className='oft' onClick={() => handleDeletePost(post.id)}>Delete</button>
          </li>
        ))}
      </ol>
    </div>
  );
}

export default App;